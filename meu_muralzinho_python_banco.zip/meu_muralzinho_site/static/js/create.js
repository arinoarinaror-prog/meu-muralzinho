document.addEventListener("DOMContentLoaded", () => {
  const picker = document.getElementById("mode-picker");
  const composer = document.getElementById("composer");
  const transcender = document.getElementById("transcender-message");
  const textarea = document.getElementById("body");
  const hiddenType = document.getElementById("post-type");
  const counter = document.getElementById("counter");
  const changeMode = document.getElementById("change-mode");
  const settings = {
    fala: { limit: 250, title: "Fala", icon: "💬", description: "Uma fala rápida para o mural." },
    pensamento: { limit: 500, title: "Pensamento", icon: "☁️", description: "Um pensamento um pouco mais demorado." }
  };

  function chooseMode(mode) {
    if (mode === "transcender") {
      picker.classList.add("hidden");
      composer.classList.add("hidden");
      transcender.classList.remove("hidden");
      return;
    }
    const config = settings[mode];
    if (!config) return;
    hiddenType.value = mode;
    textarea.maxLength = config.limit;
    textarea.value = "";
    document.getElementById("composer-title").textContent = config.title;
    document.getElementById("composer-icon").textContent = config.icon;
    document.getElementById("composer-description").textContent = config.description;
    textarea.placeholder = mode === "fala" ? "Diga o que está pensando..." : "Deixe seu pensamento por aqui...";
    counter.textContent = `0/${config.limit}`;
    picker.classList.add("hidden");
    transcender.classList.add("hidden");
    composer.classList.remove("hidden");
    textarea.focus();
  }

  picker.addEventListener("click", (event) => {
    const button = event.target.closest("[data-mode]");
    if (button) chooseMode(button.dataset.mode);
  });
  changeMode.addEventListener("click", () => {
    composer.classList.add("hidden");
    picker.classList.remove("hidden");
  });
  textarea.addEventListener("input", () => {
    counter.textContent = `${textarea.value.length}/${textarea.maxLength}`;
  });
});
