document.addEventListener("DOMContentLoaded", () => {
  const list = document.getElementById("emoji-list");
  const hidden = document.getElementById("decorations-json");
  const emojiChoice = document.getElementById("emoji-choice");
  const positionChoice = document.getElementById("emoji-position");
  const addButton = document.getElementById("add-emoji");
  const themeSelect = document.getElementById("theme-choice");
  const themeRadios = document.querySelectorAll('input[name="theme_preview"]');
  const form = document.getElementById("profile-editor");
  let decorations = Array.isArray(window.PROFILE_DECORATIONS) ? [...window.PROFILE_DECORATIONS] : [];

  function renderDecorations() {
    list.replaceChildren();
    decorations.forEach((item, index) => {
      const chip = document.createElement("div");
      chip.className = "emoji-chip";
      const label = document.createElement("span");
      label.textContent = `${item.emoji} · ${item.position.replaceAll("-", " ")}`;
      const remove = document.createElement("button");
      remove.type = "button";
      remove.textContent = "×";
      remove.setAttribute("aria-label", "Remover emoji");
      remove.addEventListener("click", () => { decorations.splice(index, 1); renderDecorations(); });
      chip.append(label, remove);
      list.append(chip);
    });
    hidden.value = JSON.stringify(decorations);
    if (!decorations.length) {
      const empty = document.createElement("p");
      empty.className = "quiet-note";
      empty.textContent = "Nenhum emoji extra adicionado ainda.";
      list.append(empty);
    }
  }

  addButton.addEventListener("click", () => {
    if (decorations.length >= 24) { alert("Você pode adicionar até 24 emojis ao perfil."); return; }
    decorations.push({ emoji: emojiChoice.value, position: positionChoice.value });
    renderDecorations();
  });
  themeRadios.forEach((radio) => radio.addEventListener("change", () => {
    if (radio.checked) themeSelect.value = radio.value;
  }));
  themeSelect.addEventListener("change", () => {
    themeRadios.forEach((radio) => { radio.checked = radio.value === themeSelect.value; });
  });
  form.addEventListener("submit", () => { hidden.value = JSON.stringify(decorations); });
  renderDecorations();
});
