document.addEventListener("DOMContentLoaded", () => {
  const first = document.getElementById("register-step-one");
  const second = document.getElementById("register-step-two");
  const next = document.getElementById("next-step");
  const back = document.getElementById("back-step");
  const dotOne = document.getElementById("step-one-dot");
  const dotTwo = document.getElementById("step-two-dot");
  const form = document.getElementById("register-form");

  next.addEventListener("click", () => {
    const email = form.elements.email;
    const password = form.elements.password;
    if (!email.reportValidity() || !password.reportValidity()) return;
    if (password.value.length < 8) {
      password.setCustomValidity("Use pelo menos 8 caracteres.");
      password.reportValidity();
      password.setCustomValidity("");
      return;
    }
    first.classList.add("hidden");
    second.classList.remove("hidden");
    dotOne.classList.remove("active");
    dotTwo.classList.add("active");
  });
  back.addEventListener("click", () => {
    second.classList.add("hidden");
    first.classList.remove("hidden");
    dotTwo.classList.remove("active");
    dotOne.classList.add("active");
  });
});
