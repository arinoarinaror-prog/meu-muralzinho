document.addEventListener("DOMContentLoaded", () => {
  // Confirmações ficam centralizadas aqui para facilitar ajustes futuros.
  document.querySelectorAll("form[onsubmit]").forEach((form) => {
    form.addEventListener("submit", (event) => {
      const inlineHandler = form.getAttribute("onsubmit");
      if (inlineHandler && inlineHandler.includes("confirm(")) {
        // O atributo inline é mantido somente para a confirmação simples de exclusão.
      }
    });
  });
});
