import os
import re
import json
import sqlite3
from datetime import datetime, timezone
from functools import wraps
from pathlib import Path

from flask import (
    Flask, abort, flash, g, redirect, render_template,
    request, session, url_for
)
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

BASE_DIR = Path(__file__).resolve().parent
INSTANCE_DIR = BASE_DIR / "instance"
UPLOAD_DIR = BASE_DIR / "static" / "uploads"
INSTANCE_DIR.mkdir(exist_ok=True)
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "troque-esta-chave-antes-de-publicar")
app.config["DATABASE"] = os.environ.get("DATABASE_PATH", str(INSTANCE_DIR / "muralzinho.sqlite3"))
app.config["MAX_CONTENT_LENGTH"] = 4 * 1024 * 1024
app.config["UPLOAD_FOLDER"] = str(UPLOAD_DIR)
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "webp", "gif"}

# TEMAS EXTENSÍVEIS: para adicionar uma nova aparência, basta colocar um
# arquivo .css em static/css/themes/ e começar o arquivo com:
# /* THEME_NAME: Nome exibido para o usuário */
# O sistema descobre os arquivos automaticamente. Não é preciso editar app.py.
def discover_themes():
    theme_dir = BASE_DIR / "static" / "css" / "themes"
    theme_dir.mkdir(parents=True, exist_ok=True)
    found = []
    for css_file in sorted(theme_dir.glob("*.css")):
        if css_file.name.startswith("_"):
            continue
        css = css_file.read_text(encoding="utf-8", errors="ignore")
        match = re.search(r"/\*\s*THEME_NAME:\s*(.*?)\s*\*/", css)
        label = match.group(1).strip() if match else css_file.stem.replace("-", " ").title()
        found.append({"id": css_file.stem, "name": label})
    return found

# Para ampliar a biblioteca de emojis, basta acrescentar novos símbolos aqui.
PROFILE_EMOJIS = [
    "🌸", "🌷", "🌼", "🌻", "🌹", "🪷", "🍓", "🍒", "🍰", "🧁",
    "🎀", "💗", "💕", "💖", "💘", "♡", "★", "☆", "✦", "✧",
    "☁️", "🌙", "⭐", "✨", "🦋", "🐈", "🐇", "🐻", "🐸", "🐱",
    "🍄", "🍀", "🌿", "🪻", "🧸", "🎧", "💿", "📼", "📷", "🪩",
    "🕯️", "🪽", "🫧", "🪞", "💌", "📓", "🖇️", "🪡", "🧷", "🦢",
    "🍬", "🍭", "🧃", "🧋", "🍡", "🧺", "🪐", "🌈", "⚡", "🤍",
]

# O schema.sql é a referência da estrutura mínima esperada pelo backend.
# Se o banco que está em desenvolvimento usar outro nome/tipo de coluna,
# ajuste get_db(), init_db() e as consultas deste arquivo para o schema real.
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db

@app.teardown_appcontext
def close_db(error=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()

def init_db():
    with app.app_context():
        db = get_db()
        schema = (BASE_DIR / "schema.sql").read_text(encoding="utf-8")
        db.executescript(schema)
        db.commit()
        # Migração compatível com SQLite criado na versão beta anterior.
        # Bancos PostgreSQL/MySQL devem receber uma migração equivalente.
        columns = {row["name"] for row in db.execute("PRAGMA table_info(profiles)").fetchall()}
        if "decorations" not in columns:
            db.execute("ALTER TABLE profiles ADD COLUMN decorations TEXT NOT NULL DEFAULT '[]'")
            db.commit()

        # Converte nomes de temas usados na versão anterior para o novo catálogo.
        available_ids = {item["id"] for item in discover_themes()}
        placeholders = ",".join("?" for _ in available_ids)
        if available_ids:
            db.execute(
                f"UPDATE profiles SET theme = 'rosa-y2k' WHERE theme NOT IN ({placeholders})",
                tuple(available_ids)
            )
            db.commit()

def current_user():
    user_id = session.get("user_id")
    if not user_id:
        return None
    return get_db().execute(
        """SELECT u.id, u.email, p.display_name, p.username, p.bio,
                  p.avatar, p.theme, p.name_color, p.post_size,
                  p.frame_style, p.sticker, p.decorations
           FROM users u JOIN profiles p ON p.user_id = u.id
           WHERE u.id = ?""",
        (user_id,)
    ).fetchone()

@app.template_filter("from_json")
def from_json_filter(value):
    try:
        return json.loads(value or "[]")
    except (ValueError, TypeError):
        return []

@app.context_processor
def inject_user():
    return {
        "current_user": current_user(),
        "available_themes": discover_themes(),
        "profile_emojis": PROFILE_EMOJIS,
    }

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("user_id"):
            flash("Entre na sua conta para continuar.", "info")
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)
    return wrapped

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

def get_posts(where="", params=()):
    rows = get_db().execute(
        f"""SELECT posts.*, profiles.display_name, profiles.username,
                   profiles.avatar, profiles.name_color, profiles.frame_style,
                   (SELECT COUNT(*) FROM likes WHERE likes.post_id = posts.id) AS like_count,
                   (SELECT COUNT(*) FROM comments WHERE comments.post_id = posts.id) AS comment_count,
                   EXISTS(SELECT 1 FROM likes WHERE likes.post_id = posts.id AND likes.user_id = ?)
                       AS liked_by_me
            FROM posts JOIN profiles ON profiles.user_id = posts.user_id
            {where}
            ORDER BY posts.created_at DESC""",
        (session.get("user_id", -1), *params)
    ).fetchall()

    # Anexa os comentários de cada Fala para que apareçam no próprio cartão.
    # Pensamentos não recebem consulta de comentários: a regra é reforçada aqui e
    # também na rota POST /post/<id>/comentar.
    posts = []
    for row in rows:
        post = dict(row)
        if post["post_type"] == "fala":
            post["comments"] = get_db().execute(
                """SELECT comments.id, comments.body, comments.created_at,
                          profiles.display_name, profiles.username
                   FROM comments
                   JOIN profiles ON profiles.user_id = comments.user_id
                   WHERE comments.post_id = ?
                   ORDER BY comments.created_at ASC""",
                (post["id"],)
            ).fetchall()
        else:
            post["comments"] = []
        posts.append(post)
    return posts

@app.route("/")
def index():
    posts = get_posts("WHERE posts.post_type IN ('fala', 'pensamento') LIMIT 80")
    return render_template("index.html", posts=posts)

@app.route("/explorar")
def explore():
    search = request.args.get("q", "").strip()
    kind = request.args.get("tipo", "todos")
    clauses, params = [], []
    if search:
        clauses.append("(posts.body LIKE ? OR profiles.username LIKE ? OR profiles.display_name LIKE ?)")
        term = f"%{search}%"
        params.extend([term, term, term])
    if kind in ("fala", "pensamento"):
        clauses.append("posts.post_type = ?")
        params.append(kind)
    where = "WHERE " + " AND ".join(clauses) if clauses else ""
    posts = get_posts(where + " LIMIT 100", tuple(params))
    return render_template("explorar.html", posts=posts, q=search, tipo=kind)

@app.route("/criar", methods=["GET", "POST"])
@login_required
def create_post():
    if request.method == "POST":
        post_type = request.form.get("post_type", "")
        body = request.form.get("body", "").strip()
        limits = {"fala": 250, "pensamento": 500}
        if post_type == "transcender":
            flash("Modo incompleto, volte mais tarde 💋", "warning")
            return redirect(url_for("create_post"))
        if post_type not in limits:
            flash("Escolha um modo de publicação válido.", "error")
        elif not body:
            flash("Escreva alguma coisa antes de publicar.", "error")
        elif len(body) > limits[post_type]:
            flash(f"Esse modo permite até {limits[post_type]} caracteres.", "error")
        else:
            get_db().execute(
                "INSERT INTO posts (user_id, post_type, body, created_at) VALUES (?, ?, ?, ?)",
                (session["user_id"], post_type, body, datetime.now(timezone.utc).isoformat())
            )
            get_db().commit()
            flash("Sua publicação chegou ao mural! ✨", "success")
            return redirect(url_for("index"))
        return redirect(url_for("create_post"))
    return render_template("criar.html")

@app.route("/post/<int:post_id>/curtir", methods=["POST"])
@login_required
def like_post(post_id):
    db = get_db()
    post = db.execute("SELECT id FROM posts WHERE id = ?", (post_id,)).fetchone()
    if not post:
        abort(404)
    existing = db.execute(
        "SELECT 1 FROM likes WHERE post_id = ? AND user_id = ?",
        (post_id, session["user_id"])
    ).fetchone()
    if existing:
        db.execute("DELETE FROM likes WHERE post_id = ? AND user_id = ?", (post_id, session["user_id"]))
    else:
        db.execute("INSERT INTO likes (post_id, user_id) VALUES (?, ?)", (post_id, session["user_id"]))
    db.commit()
    return redirect(request.referrer or url_for("index"))

@app.route("/post/<int:post_id>/comentar", methods=["POST"])
@login_required
def comment_post(post_id):
    db = get_db()
    post = db.execute("SELECT post_type FROM posts WHERE id = ?", (post_id,)).fetchone()
    body = request.form.get("body", "").strip()
    if not post:
        abort(404)
    if post["post_type"] != "fala":
        abort(403)
    if not body or len(body) > 500:
        flash("O comentário precisa ter entre 1 e 500 caracteres.", "error")
    else:
        db.execute(
            "INSERT INTO comments (post_id, user_id, body, created_at) VALUES (?, ?, ?, ?)",
            (post_id, session["user_id"], body, datetime.now(timezone.utc).isoformat())
        )
        db.commit()
        flash("Comentário publicado.", "success")
    return redirect(request.referrer or url_for("index"))

@app.route("/post/<int:post_id>/excluir", methods=["POST"])
@login_required
def delete_post(post_id):
    db = get_db()
    post = db.execute("SELECT user_id FROM posts WHERE id = ?", (post_id,)).fetchone()
    if not post:
        abort(404)
    if post["user_id"] != session["user_id"]:
        abort(403)
    db.execute("DELETE FROM posts WHERE id = ?", (post_id,))
    db.commit()
    flash("Publicação removida.", "success")
    return redirect(request.referrer or url_for("index"))

@app.route("/perfil")
@login_required
def profile():
    user_id = session["user_id"]
    profile_row = current_user()
    posts = get_posts("WHERE posts.user_id = ? LIMIT 100", (user_id,))
    return render_template("perfil.html", profile=profile_row, posts=posts)

@app.route("/perfil/editar", methods=["GET", "POST"])
@login_required
def edit_profile():
    db = get_db()
    profile_row = current_user()
    if request.method == "POST":
        display_name = request.form.get("display_name", "").strip()[:40]
        username = request.form.get("username", "").strip().lstrip("@").lower()
        bio = request.form.get("bio", "").strip()[:180]
        theme = request.form.get("theme", "pink")
        name_color = request.form.get("name_color", "#9b3978")
        post_size = request.form.get("post_size", "normal")
        frame_style = request.form.get("frame_style", "dashed")
        sticker = request.form.get("sticker", "✿")
        # Cada emoji decorativo é salvo como {emoji, position} em JSON.
        # Posições permitidas: oito áreas ao redor do perfil, responsivas no mobile.
        raw_decorations = request.form.get("decorations_json", "[]")
        allowed_positions = {
            "top-left", "top-center", "top-right", "middle-left",
            "middle-right", "bottom-left", "bottom-center", "bottom-right"
        }
        try:
            requested = json.loads(raw_decorations)
            if not isinstance(requested, list):
                requested = []
            clean = []
            for item in requested[:24]:
                if not isinstance(item, dict):
                    continue
                emoji = str(item.get("emoji", ""))[:8]
                position = str(item.get("position", "top-right"))
                if emoji in PROFILE_EMOJIS and position in allowed_positions:
                    clean.append({"emoji": emoji, "position": position})
            decorations_json = json.dumps(clean, ensure_ascii=False)
        except (ValueError, TypeError):
            decorations_json = "[]"
        if not display_name or not username or not username.replace("_", "").isalnum():
            flash("Preencha o nome e use um @ com letras, números ou _.", "error")
            return redirect(url_for("edit_profile"))
        duplicate = db.execute(
            "SELECT user_id FROM profiles WHERE username = ? AND user_id != ?",
            (username, session["user_id"])
        ).fetchone()
        if duplicate:
            flash("Esse @ já está em uso.", "error")
            return redirect(url_for("edit_profile"))
        avatar = profile_row["avatar"]
        upload = request.files.get("avatar")
        if upload and upload.filename:
            if not allowed_file(upload.filename):
                flash("Use uma imagem PNG, JPG, WEBP ou GIF.", "error")
                return redirect(url_for("edit_profile"))
            filename = secure_filename(upload.filename)
            unique_name = f"user{session['user_id']}_{int(datetime.now().timestamp())}_{filename}"
            upload.save(UPLOAD_DIR / unique_name)
            avatar = f"uploads/{unique_name}"
        # O seletor é abastecido pelos arquivos CSS encontrados na pasta themes.
        allowed_themes = {item["id"] for item in discover_themes()}
        allowed_sizes = {"compact", "normal", "large"}
        allowed_frames = {"none", "dashed", "solid", "double"}
        db.execute(
            """UPDATE profiles SET display_name=?, username=?, bio=?, avatar=?,
               theme=?, name_color=?, post_size=?, frame_style=?, sticker=?, decorations=?
               WHERE user_id=?""",
            (display_name, username, bio, avatar,
             theme if theme in allowed_themes else "rosa-y2k",
             name_color if name_color.startswith("#") and len(name_color) == 7 else "#9b3978",
             post_size if post_size in allowed_sizes else "normal",
             frame_style if frame_style in allowed_frames else "dashed",
             sticker[:8], decorations_json, session["user_id"])
        )
        db.commit()
        flash("Seu perfil foi atualizado! ✨", "success")
        return redirect(url_for("profile"))
    return render_template("editar_perfil.html", profile=profile_row)

@app.route("/cadastro", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        display_name = request.form.get("display_name", "").strip()[:40]
        username = request.form.get("username", "").strip().lstrip("@").lower()
        accepted = request.form.get("accept_terms") == "yes"
        if not accepted:
            flash("Você precisa aceitar os Termos de Uso e a Política de Privacidade.", "error")
        elif not email or "@" not in email or len(password) < 8:
            flash("Informe um e-mail válido e uma senha com pelo menos 8 caracteres.", "error")
        elif not display_name or not username or not username.replace("_", "").isalnum():
            flash("Informe seu nome público e um @ válido.", "error")
        else:
            db = get_db()
            try:
                cursor = db.execute(
                    "INSERT INTO users (email, password_hash, created_at) VALUES (?, ?, ?)",
                    (email, generate_password_hash(password), datetime.now(timezone.utc).isoformat())
                )
                user_id = cursor.lastrowid
                db.execute(
                    """INSERT INTO profiles (user_id, display_name, username, bio, theme)
                       VALUES (?, ?, ?, '', 'rosa-y2k')""",
                    (user_id, display_name, username)
                )
                db.commit()
                session.clear()
                session["user_id"] = user_id
                flash("Conta criada! Bem-vindo ao seu muralzinho. 💗", "success")
                return redirect(url_for("index"))
            except sqlite3.IntegrityError:
                db.rollback()
                flash("Este e-mail ou @ já está cadastrado.", "error")
    return render_template("cadastro.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = get_db().execute("SELECT id, password_hash FROM users WHERE email = ?", (email,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            return redirect(request.args.get("next") or url_for("index"))
        flash("E-mail ou senha incorretos.", "error")
    return render_template("login.html")

@app.route("/sair", methods=["POST"])
def logout():
    session.clear()
    flash("Você saiu da sua conta.", "info")
    return redirect(url_for("index"))

@app.route("/termos")
def terms():
    return render_template("termos.html")

@app.route("/privacidade")
def privacy():
    return render_template("privacidade.html")

@app.route("/configuracoes")
def settings_404():
    return render_template("404.html"), 404

@app.errorhandler(404)
def not_found(error):
    return render_template("404.html"), 404

@app.errorhandler(403)
def forbidden(error):
    return render_template("403.html"), 403

@app.route("/inicializar-banco")
def initialize_database():
    # Rota auxiliar APENAS para desenvolvimento local. Remova/desative antes de publicar.
    if not app.debug:
        abort(404)
    init_db()
    return "Banco inicializado. Remova esta rota antes de publicar."

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
