# Meu Muralzinho — versão full-stack beta

Projeto Flask com templates HTML, CSS decorativo e JavaScript organizado em arquivos separados.

## 1. Requisitos
- Python 3.10 ou superior
- pip

## 2. Instalação local
```bash
python -m venv .venv
# Windows:
.venv\\Scripts\\activate
# Linux/macOS/Android com terminal compatível:
source .venv/bin/activate

pip install -r requirements.txt
python app.py
```
Abra `http://127.0.0.1:5000`.

O banco SQLite é criado automaticamente em `instance/muralzinho.sqlite3` na primeira execução.

## 3. Banco de dados em desenvolvimento
O arquivo `schema.sql` documenta o contrato mínimo esperado pelo backend:
- `users`: id, email único, password_hash, created_at
- `profiles`: user_id, display_name, username único, bio, avatar e preferências visuais
- `posts`: id, user_id, post_type (`fala` ou `pensamento`), body, created_at
- `comments`: post_id, user_id, body, created_at
- `likes`: relação única entre post_id e user_id

**Importante para integrar o banco que já está sendo desenvolvido:** não crie tabelas duplicadas sem comparar os modelos existentes. Compare o banco atual com `schema.sql`. Se nomes, tipos ou relacionamentos forem diferentes, ajuste as consultas SQL em `app.py` ou crie uma camada de repositório/adaptador. Senhas devem ser guardadas como hash seguro, nunca em texto puro. Use IDs internos e chaves estrangeiras. A regra “comentário somente em Fala” também é validada no backend, não apenas na interface.

Se o banco definitivo for PostgreSQL/MySQL, substitua o conector `sqlite3` por SQLAlchemy ou pelo driver correspondente e adapte `init_db()`/consultas. O `schema.sql` atual é SQLite.

## 4. Funcionalidades
- Cadastro em duas etapas na interface; aceite de termos obrigatório.
- Login e logout com senha armazenada via hash Werkzeug.
- Feed e Explorar consultam as mesmas publicações no banco.
- Fala: até 250 caracteres e aceita comentários.
- Pensamento: até 500 caracteres e não aceita comentários.
- Transcender: mensagem de modo incompleto, sem editor.
- Curtidas, exclusão pelo autor, perfil editável e upload de foto.
- Perfil: nome, @, bio, foto, tema, cor do nome, tamanho de post, moldura e adesivo.
- Configurações: página 404 proposital.

## 5. Antes de publicar na internet
Esta é uma base beta, não um lançamento pronto. Antes de produção:
1. Defina `SECRET_KEY` forte por variável de ambiente.
2. Desative `debug=True` e remova a rota `/inicializar-banco`.
3. Use servidor WSGI (ex.: gunicorn) e HTTPS.
4. Configure limites, validação e análise de uploads, backups e logs.
5. Implemente exclusão/exportação de dados e canal de contato de privacidade.
6. Revise Termos e Política com orientação jurídica/LGPD.
7. Adicione proteção CSRF (ex.: Flask-WTF), rate limiting e verificação de e-mail.
8. Configure moderação, denúncias e controles de abuso para conteúdo público.
9. Teste migrações do banco antes de substituir schema em produção.

## 6. Observações de design
O CSS está centralizado em `static/css/style.css`. Os comportamentos ficam em `static/js/`. Templates ficam em `templates/`. A página de perfil possui classes próprias para evoluir para um editor visual mais amplo.


## Aparências expansíveis
Os temas são descobertos automaticamente em `static/css/themes/`.
Para adicionar um novo: crie `novo-visual.css` nessa pasta e coloque na primeira linha
`/* THEME_NAME: Nome visível */`. Escreva nele apenas as regras que diferenciam a aparência
(body, .topbar, .hero-panel, .post-card, .primary-button etc.). Reinicie o Flask: o tema
aparecerá automaticamente no seletor do perfil. Não é necessário editar app.py ou HTML.

## Emojis no perfil
O usuário pode adicionar até 24 emojis e escolher entre oito posições no perfil.
A lista fica em `PROFILE_EMOJIS`, no início de `app.py`. Para adicionar símbolos, acrescente-os
à lista. Os posicionamentos são persistidos no campo `profiles.decorations` como JSON.
A inicialização do SQLite adiciona essa coluna a bancos antigos automaticamente; em banco
externo, faça uma migração equivalente antes de atualizar o backend.
