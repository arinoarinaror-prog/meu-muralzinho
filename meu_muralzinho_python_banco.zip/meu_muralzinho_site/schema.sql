-- ESQUEMA MÍNIMO DO MEU MURALZINHO
-- O banco que está em desenvolvimento deve fornecer estas entidades/campos
-- ou um mapeamento equivalente. Se os nomes forem diferentes, adapte as
-- consultas em app.py antes de conectar o banco definitivo.
--
-- Relações:
-- users 1---1 profiles
-- users 1---N posts
-- posts 1---N comments (somente posts do tipo 'fala')
-- users N---N posts através de likes

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL, -- Nunca guardar senha em texto puro.
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS profiles (
    user_id INTEGER PRIMARY KEY,
    display_name TEXT NOT NULL,
    username TEXT NOT NULL UNIQUE,
    bio TEXT NOT NULL DEFAULT '',
    avatar TEXT,
    theme TEXT NOT NULL DEFAULT 'rosa-y2k',
    name_color TEXT NOT NULL DEFAULT '#9b3978',
    post_size TEXT NOT NULL DEFAULT 'normal',
    frame_style TEXT NOT NULL DEFAULT 'dashed',
    sticker TEXT NOT NULL DEFAULT '✿',
    decorations TEXT NOT NULL DEFAULT '[]', -- JSON com emojis e posições
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS posts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    post_type TEXT NOT NULL CHECK (post_type IN ('fala', 'pensamento')),
    body TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS comments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    post_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    body TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS likes (
    post_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (post_id, user_id),
    FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_posts_created_at ON posts(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_posts_user_id ON posts(user_id);
CREATE INDEX IF NOT EXISTS idx_comments_post_id ON comments(post_id);
